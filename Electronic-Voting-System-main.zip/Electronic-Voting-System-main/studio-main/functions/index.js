const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp();
const db = admin.firestore();

exports.rfidScan = functions.https.onRequest(async (req, res) => {

  const uid = req.body.uid;

  if (!uid) {
    return res.status(400).json({ error: "UID missing" });
  }

  try {
    const snapshot = await db.collection("voters")
      .where("uid", "==", uid)
      .get();

    if (snapshot.empty) {
      return res.json({ status: "NOT_REGISTERED" });
    }

    const voter = snapshot.docs[0].data();

    if (voter.hasVoted) {
      return res.json({ status: "ALREADY_VOTED" });
    }

    return res.json({
      status: "VALID",
      name: voter.name,
      hasVoted: voter.hasVoted
    });

  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});