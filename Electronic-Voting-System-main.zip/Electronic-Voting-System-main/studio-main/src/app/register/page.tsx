"use client";

import { useState, useEffect } from 'react';
import { api } from '@/lib/api';
import { useScanner } from '@/hooks/use-scanner';
import { Navigation } from '@/components/Navigation';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Loader2, UserPlus, CreditCard, CheckCircle2, AlertCircle, Wifi } from 'lucide-react';

export default function Register() {
  const lastScan = useScanner();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [scannedUid, setScannedUid] = useState<string>('');
  const [voters, setVoters] = useState<any[]>([]);
  const [formData, setFormData] = useState({
    name: '',
    department: '',
    registerNumber: '',
    year: '',
  });

  // Poll for voter list updates
  useEffect(() => {
    const loadVoters = async () => {
      try {
        const votersData = await api.getVoters();
        setVoters(votersData);
      } catch (error) {
        console.error('Failed to load voters:', error);
      }
    };

    loadVoters();
    // Poll for updates every 2 seconds
    const interval = setInterval(loadVoters, 2000);
    return () => clearInterval(interval);
  }, []);

  // Automatically pick up UID when scanned
  useEffect(() => {
    if (lastScan && (Date.now() - lastScan.lastScannedAt < 15000)) {
      setScannedUid(lastScan.lastScannedUid);
    }
  }, [lastScan]);

  const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();

  if (!scannedUid) {
    toast({
      title: "No card detected",
      description: "Please scan an RFID card using the hardware reader first.",
      variant: "destructive"
    });
    return;
  }

  setLoading(true);

  try {
    // Check duplicate
    const existingVoter = voters.find(v => v.uid === scannedUid);
    if (existingVoter) {
      toast({
        title: "Registration Error",
        description: "This RFID card is already registered.",
        variant: "destructive"
      });
      return;
    }

    // ✅ FIX: SEND UID
    await api.addVoter({
      uid: scannedUid,   // 🔥 IMPORTANT FIX
      name: formData.name,
      department: formData.department,
      registerNumber: formData.registerNumber,
      year: formData.year,
      hasVoted: false,
      timestamp: new Date().toISOString()
    });

    toast({
      title: "Voter Registered",
      description: `${formData.name} has been added successfully.`,
    });

    // Reset form
    setFormData({
      name: '',
      department: '',
      registerNumber: '',
      year: '',
    });

    setScannedUid('');

  } catch (error) {
    console.error(error);
    toast({
      title: "Error",
      description: "Failed to save registration.",
      variant: "destructive"
    });
  } finally {
    setLoading(false);
  }
};

  const isScanRecent = scannedUid !== '' && (lastScan && Date.now() - lastScan.lastScannedAt < 30000);

  return (
    <div className="min-h-screen gradient-bg pb-20 md:pt-20">
      <Navigation />
      
      <main className="max-w-3xl mx-auto px-4 pt-12">
        <div className="flex flex-col items-center mb-10 text-center">
          <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mb-4">
            <UserPlus className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-4xl font-headline font-bold mb-2">Registration</h1>
          <p className="text-muted-foreground">Tap hardware reader to auto-fill identity UID.</p>
        </div>

        <div className="grid gap-8">
          <Card className={`border-2 transition-all duration-500 ${isScanRecent ? 'border-green-500 bg-green-500/5 shadow-[0_0_20px_rgba(34,197,94,0.1)]' : 'border-border'}`}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-6">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${isScanRecent ? 'bg-green-500 text-white' : 'bg-muted text-muted-foreground'}`}>
                  <CreditCard className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-muted-foreground">Hardware Scan UID</p>
                  <div className="flex items-center gap-2">
                    {isScanRecent ? (
                      <span className="text-lg font-bold font-code tracking-widest">{scannedUid}</span>
                    ) : (
                      <span className="text-muted-foreground italic flex items-center gap-2">
                        <Wifi className="w-4 h-4 animate-pulse" /> Waiting for ESP32 signal...
                      </span>
                    )}
                  </div>
                </div>
                {isScanRecent && <CheckCircle2 className="w-6 h-6 text-green-500" />}
              </div>
            </CardContent>
          </Card>

          {/* Registered Voters List */}
          <Card className="bg-card/50 backdrop-blur border-border shadow-xl">
            <CardHeader>
              <CardTitle>Registered Voters ({voters.length})</CardTitle>
              <CardDescription>Live list of all registered voters in the database.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {voters.length > 0 ? (
                  voters.map((voter) => (
                    <div key={voter.uid} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                          <CreditCard className="w-4 h-4 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">{voter.name}</p>
                          <p className="text-sm text-muted-foreground">{voter.department} • {voter.year}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className={`px-2 py-1 rounded-full text-[10px] font-bold ${
                          voter.hasVoted 
                            ? 'bg-green-500/20 text-green-500' 
                            : 'bg-amber-500/20 text-amber-500'
                        }`}>
                          {voter.hasVoted ? 'VOTED' : 'PENDING'}
                        </span>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-center text-muted-foreground py-8">No voters registered yet.</p>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/50 backdrop-blur border-border shadow-xl">
            <form onSubmit={handleSubmit}>
              <CardHeader>
                <CardTitle>Voter Information</CardTitle>
                <CardDescription>All details will be linked to the scanned RFID UID.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Linked UID (Auto-filled)</Label>
                  <Input 
                    value={scannedUid} 
                    readOnly 
                    className="bg-muted font-code" 
                    placeholder="Scan card to fill..."
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input 
                      id="name" 
                      required 
                      value={formData.name}
                      onChange={e => setFormData({...formData, name: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="reg">Register Number</Label>
                    <Input 
                      id="reg" 
                      required 
                      value={formData.registerNumber}
                      onChange={e => setFormData({...formData, registerNumber: e.target.value})}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Department</Label>
                    <Select onValueChange={v => setFormData({...formData, department: v})} required value={formData.department}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="CSE">Computer Science</SelectItem>
                        <SelectItem value="ECE">Electronics</SelectItem>
                        <SelectItem value="MECH">Mechanical</SelectItem>
                        <SelectItem value="IT">Information Tech</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Year</Label>
                    <Select onValueChange={v => setFormData({...formData, year: v})} required value={formData.year}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1st">1st Year</SelectItem>
                        <SelectItem value="2nd">2nd Year</SelectItem>
                        <SelectItem value="3rd">3rd Year</SelectItem>
                        <SelectItem value="4th">4th Year</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  type="submit" 
                  className="w-full h-11" 
                  disabled={loading || !isScanRecent}
                >
                  {loading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <UserPlus className="w-5 h-5 mr-2" />}
                  Register Student
                </Button>
              </CardFooter>
            </form>
          </Card>
        </div>
      </main>
    </div>
  );
}
