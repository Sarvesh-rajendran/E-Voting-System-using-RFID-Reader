"use client";

import { useState, useEffect } from 'react';
import { api, Candidate, Voter } from '@/lib/api';
import { Navigation } from '@/components/Navigation';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { detectVotingAnomalies, DetectVotingAnomaliesOutput } from '@/ai/flows/voting-anomaly-detector';
import { Loader2, Plus, Trash2, RotateCcw, ShieldAlert, Activity, ListChecks, Users, Fingerprint, Database } from 'lucide-react';

export default function AdminPage() {
  const { toast } = useToast();
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [voters, setVoters] = useState<Voter[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [newCandidate, setNewCandidate] = useState({ name: '', position: 'President' });
  const [loading, setLoading] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<DetectVotingAnomaliesOutput | null>(null);
  const [analyzing, setAnalyzing] = useState(false);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [candidatesData, logsData, votersData] = await Promise.all([
          api.getCandidates(),
          api.getVoteLogs(),
          api.getVoters()
        ]);
        
        setCandidates(candidatesData);
        setLogs(logsData);
        setVoters(votersData);
      } catch (error) {
        console.error('Failed to load admin data:', error);
      }
    };

    loadData();
    // Poll for updates every 2 seconds
    const interval = setInterval(loadData, 2000);
    return () => clearInterval(interval);
  }, []);

  const handleAddCandidate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.addCandidate({
        name: newCandidate.name,
        position: newCandidate.position,
        votes: 0
      });
      setNewCandidate({ name: '', position: 'President' });
      toast({ title: "Candidate Registered" });
    } catch (error) {
      toast({ title: "Failed to add candidate", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteCandidate = async (id: string) => {
    try {
      await api.deleteCandidate(id);
      toast({ title: "Candidate Removed" });
    } catch (error) {
      toast({ title: "Failed to delete candidate", variant: "destructive" });
    }
  };

  const handleDeleteVoter = async (uid: string) => {
    try {
      // This would need to be implemented in the backend API
      await fetch(`http://localhost:5000/api/voters/${uid}`, {
        method: 'DELETE'
      });
      toast({ title: "Voter Removed" });
    } catch (error) {
      toast({ title: "Failed to delete voter", variant: "destructive" });
    }
  };

  const handleResetElection = async () => {
    if (!confirm("CRITICAL: This will wipe ALL votes, scan logs, and reset voter status. Continue?")) return;
    
    setLoading(true);
    try {
      await api.resetVotes();
      setAiAnalysis(null);
      toast({ title: "System Database Purged" });
    } catch (error) {
      toast({ title: "Reset Failed", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const runAiAnalysis = async () => {
    if (logs.length === 0) return;
    setAnalyzing(true);
    try {
      const result = await detectVotingAnomalies({
        recentVotingActivityLogs: logs.slice(0, 20).map(l => ({
          uid: l.uid,
          timestamp: l.timestamp,
          candidateId: l.candidateId,
          transactionHash: l.transactionHash || 'SECURE_API_LOG'
        }))
      });
      setAiAnalysis(result);
    } catch (e) {
      toast({ title: "AI Analysis Error", variant: "destructive" });
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen gradient-bg pb-20 md:pt-20">
      <Navigation />
      
      <main className="max-w-6xl mx-auto px-4 pt-12">
        <header className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
          <div>
            <h1 className="text-4xl font-headline font-bold mb-2">Admin Control</h1>
            <p className="text-muted-foreground">Manage nominations and monitor election integrity.</p>
          </div>
          <Button variant="destructive" onClick={handleResetElection} disabled={loading} className="w-full md:w-auto font-bold">
            <RotateCcw className="w-4 h-4 mr-2" />
            Purge Election Data
          </Button>
        </header>

        <Tabs defaultValue="candidates" className="space-y-6">
          <TabsList className="bg-card/50 backdrop-blur border-border p-1 h-auto flex-wrap">
            <TabsTrigger value="candidates" className="px-6 py-2">
              <ListChecks className="w-4 h-4 mr-2" /> Candidates
            </TabsTrigger>
            <TabsTrigger value="voters" className="px-6 py-2">
              <Users className="w-4 h-4 mr-2" /> Voters
            </TabsTrigger>
            <TabsTrigger value="integrity" className="px-6 py-2">
              <ShieldAlert className="w-4 h-4 mr-2" /> AI Auditor
            </TabsTrigger>
            <TabsTrigger value="logs" className="px-6 py-2">
              <Activity className="w-4 h-4 mr-2" /> Vote Logs
            </TabsTrigger>
          </TabsList>

          <TabsContent value="candidates" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <Card className="lg:col-span-1 bg-card/50 backdrop-blur border-border h-fit">
                <CardHeader>
                  <CardTitle>Register Nominee</CardTitle>
                </CardHeader>
                <form onSubmit={handleAddCandidate}>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label>Full Name</Label>
                      <Input 
                        required 
                        placeholder="e.g. John Doe"
                        value={newCandidate.name} 
                        onChange={e => setNewCandidate({...newCandidate, name: e.target.value})} 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Position</Label>
                      <Input 
                        required 
                        placeholder="e.g. Student Council President"
                        value={newCandidate.position} 
                        onChange={e => setNewCandidate({...newCandidate, position: e.target.value})} 
                      />
                    </div>
                  </CardContent>
                  <CardContent>
                    <Button type="submit" className="w-full" disabled={loading}>
                      <Plus className="w-4 h-4 mr-2" /> Add to Ballot
                    </Button>
                  </CardContent>
                </form>
              </Card>

              <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                {candidates.map(c => (
                  <Card key={c.id} className="bg-card/30 border-border border-l-4 border-l-primary">
                    <CardHeader className="flex flex-row items-center justify-between pb-2">
                      <div>
                        <CardTitle className="text-lg">{c.name}</CardTitle>
                        <CardDescription>{c.position}</CardDescription>
                      </div>
                      <Button variant="ghost" size="icon" className="text-destructive hover:bg-destructive/10" onClick={() => handleDeleteCandidate(c.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-primary">{c.votes} <span className="text-sm text-muted-foreground font-normal">Verified Votes</span></div>
                    </CardContent>
                  </Card>
                ))}
                {candidates.length === 0 && (
                  <div className="col-span-2 py-20 text-center border-2 border-dashed border-border rounded-lg">
                    <p className="text-muted-foreground italic">No nominations added yet.</p>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="voters">
            <Card className="bg-card/50 backdrop-blur border-border">
              <CardHeader>
                <CardTitle>Voter Registry</CardTitle>
                <CardDescription>Comprehensive list of all RFID-registered voters in the database.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border text-muted-foreground text-left">
                        <th className="pb-4 font-medium uppercase text-xs">UID</th>
                        <th className="pb-4 font-medium uppercase text-xs">Name</th>
                        <th className="pb-4 font-medium uppercase text-xs">Dept</th>
                        <th className="pb-4 font-medium uppercase text-xs">Status</th>
                        <th className="pb-4 font-medium uppercase text-xs text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {voters.map((voter) => (
                        <tr key={voter.uid} className="hover:bg-primary/5 transition-colors">
                          <td className="py-3 font-code text-primary font-bold">{voter.uid}</td>
                          <td className="py-3">{voter.name}</td>
                          <td className="py-3 text-muted-foreground">{voter.department}</td>
                          <td className="py-3">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              voter.hasVoted ? 'bg-green-500/20 text-green-500' : 'bg-amber-500/20 text-amber-500'
                            }`}>
                              {voter.hasVoted ? 'VOTED' : 'PENDING'}
                            </span>
                          </td>
                          <td className="py-3 text-right">
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => handleDeleteVoter(voter.uid)}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                      {voters.length === 0 && (
                        <tr><td colSpan={5} className="py-10 text-center text-muted-foreground italic">No voters registered.</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="integrity">
            <Card className="bg-card/50 backdrop-blur border-border">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>AI Fraud Detection</CardTitle>
                    <CardDescription>Analyzing behavioral patterns in RFID scan sequences</CardDescription>
                  </div>
                  <Button onClick={runAiAnalysis} disabled={analyzing || logs.length === 0}>
                    {analyzing ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <ShieldAlert className="w-4 h-4 mr-2" />}
                    Begin Audit
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {aiAnalysis ? (
                  <div className={`p-6 rounded-lg border-2 ${aiAnalysis.hasAnomalies ? 'border-destructive bg-destructive/10' : 'border-green-500/50 bg-green-500/10'}`}>
                    <div className="flex items-center gap-4 mb-4">
                      <div className={`px-3 py-1 rounded text-xs font-bold uppercase ${
                        aiAnalysis.alertLevel === 'HIGH' ? 'bg-destructive text-white' : 'bg-green-500 text-white'
                      }`}>
                        Status: {aiAnalysis.alertLevel}
                      </div>
                      <span className="text-lg font-bold">{aiAnalysis.hasAnomalies ? 'Security Warning' : 'Logs Verified'}</span>
                    </div>
                    <p className="text-sm leading-relaxed mb-4">{aiAnalysis.summary}</p>
                    {aiAnalysis.detectedPatterns.length > 0 && (
                      <ul className="list-disc list-inside text-sm space-y-1 text-muted-foreground">
                        {aiAnalysis.detectedPatterns.map((p, i) => <li key={i}>{p}</li>)}
                      </ul>
                    )}
                  </div>
                ) : (
                  <div className="py-20 text-center text-muted-foreground border-2 border-dashed border-border rounded-lg">
                    <ShieldAlert className="w-12 h-12 mx-auto mb-4 opacity-20" />
                    <p>Audit trail clear. Scan logs to initiate AI security check.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="logs">
            <Card className="bg-card/50 backdrop-blur border-border">
              <CardHeader>
                <CardTitle>Hardware Audit Trail</CardTitle>
                <CardDescription>Live feed of API-authenticated votes from backend</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-border text-muted-foreground">
                        <th className="text-left pb-4 font-medium uppercase">RFID UID</th>
                        <th className="text-left pb-4 font-medium uppercase">Recipient</th>
                        <th className="text-left pb-4 font-medium uppercase">Time</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {logs.map((log, i) => (
                        <tr key={i} className="hover:bg-primary/5 transition-colors">
                          <td className="py-3 font-code text-primary font-bold">{log.uid}</td>
                          <td className="py-3 text-muted-foreground">{log.candidateId}</td>
                          <td className="py-3 font-mono">{new Date(log.timestamp).toLocaleString()}</td>
                        </tr>
                      ))}
                      {logs.length === 0 && (
                        <tr><td colSpan={3} className="py-10 text-center text-muted-foreground italic">No votes logged in this session.</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
