"use client";

import { useEffect, useState } from 'react';
import { api, Voter, Candidate } from '@/lib/api';
import { Navigation } from '@/components/Navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Users, Vote as VoteIcon, TrendingUp, BarChart3, AlertCircle, ShieldCheck, Activity, Cpu } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

export default function Dashboard() {
  const [voters, setVoters] = useState<Voter[]>([]);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [votes, setVotes] = useState<any[]>([]);
  const [recentScans, setRecentScans] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [votersData, candidatesData, votesData, scansData] = await Promise.all([
          api.getVoters(),
          api.getCandidates(),
          api.getVoteLogs(),
          api.getRecentScans()
        ]);
        
        setVoters(votersData);
        setCandidates(candidatesData);
        setVotes(votesData);
        setRecentScans(scansData);
        setLoading(false);
      } catch (error) {
        console.error('Failed to load dashboard data:', error);
        setLoading(false);
      }
    };

    loadData();
    // Poll for updates every 2 seconds
    const interval = setInterval(loadData, 2000);
    return () => clearInterval(interval);
  }, []);

  const totalRegistered = voters.length;
  const totalVotesCast = votes.length;
  const participationRate = totalRegistered > 0 ? (totalVotesCast / totalRegistered) * 100 : 0;

  const chartData = candidates.map(c => ({
    name: c.name,
    votes: c.votes
  }));

  const COLORS = ['hsl(var(--primary))', 'hsl(var(--accent))', 'hsl(200, 100%, 50%)', 'hsl(180, 100%, 50%)'];

  return (
    <div className="min-h-screen gradient-bg pb-20 md:pt-20">
      <Navigation />
      
      <main className="max-w-7xl mx-auto px-4 pt-8">
        <header className="mb-8">
          <h1 className="text-4xl font-headline font-extrabold tracking-tight mb-2">Election Insights</h1>
          <p className="text-muted-foreground flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
            Hardware Interface Connected: Monitoring backend API
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-card/50 backdrop-blur border-border shadow-xl">
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-sm font-medium">Registered Voters</CardTitle>
              <Users className="w-4 h-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{totalRegistered}</div>
              <p className="text-xs text-muted-foreground mt-1">Live /voters count</p>
            </CardContent>
          </Card>

          <Card className="bg-card/50 backdrop-blur border-border shadow-xl">
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-sm font-medium">Verified Ballots</CardTitle>
              <VoteIcon className="w-4 h-4 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{totalVotesCast}</div>
              <p className="text-xs text-muted-foreground mt-1">Live /votes count</p>
            </CardContent>
          </Card>

          <Card className="bg-card/50 backdrop-blur border-border shadow-xl">
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-sm font-medium">Participation</CardTitle>
              <TrendingUp className="w-4 h-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{participationRate.toFixed(1)}%</div>
              <Progress value={participationRate} className="h-1.5 mt-3" />
            </CardContent>
          </Card>

          <Card className="bg-card/50 backdrop-blur border-border shadow-xl border-primary/20">
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-sm font-medium">System Status</CardTitle>
              <Cpu className="w-4 h-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-lg font-bold text-green-500 uppercase">Operational</div>
              <p className="text-[10px] text-muted-foreground mt-1 font-mono">ESP32 POLLING ACTIVE</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <Card className="lg:col-span-2 bg-card/50 backdrop-blur border-border shadow-xl min-h-[400px]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                Live Standings
              </CardTitle>
            </CardHeader>
            <CardContent className="h-[300px]">
              {chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" vertical={false} />
                    <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                    <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))' }}
                    />
                    <Bar dataKey="votes" radius={[4, 4, 0, 0]}>
                      {chartData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-muted-foreground opacity-30">
                  <AlertCircle className="w-12 h-12 mb-4" />
                  <p>No candidates registered in database</p>
                </div>
              )}
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card className="bg-card/50 backdrop-blur border-border shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-sm">
                  <Activity className="w-4 h-4 text-primary" />
                  Live Hardware Log
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentScans.length > 0 ? (
                    recentScans.map((scan, i) => (
                      <div key={i} className="flex items-start gap-3 text-xs border-l-2 border-primary/30 pl-3 py-1">
                        <div className="flex-1">
                          <p className="font-code text-primary">{scan.uid}</p>
                          <p className="text-muted-foreground">{new Date(scan.timestamp).toLocaleTimeString()}</p>
                        </div>
                        <span className="bg-primary/10 text-primary px-2 py-0.5 rounded">TAP</span>
                      </div>
                    ))
                  ) : (
                    <p className="text-xs text-muted-foreground italic text-center py-4">Waiting for hardware signal...</p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card/50 backdrop-blur border-border shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-sm">
                  <ShieldCheck className="w-4 h-4 text-accent" />
                  Candidate Breakdown
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {candidates.map((c, idx) => (
                  <div key={c.id} className="space-y-1">
                    <div className="flex justify-between text-[11px]">
                      <span>{c.name}</span>
                      <span className="font-bold">{c.votes}</span>
                    </div>
                    <Progress 
                      value={totalVotesCast > 0 ? (c.votes / totalVotesCast) * 100 : 0} 
                      className="h-1"
                      style={{ '--primary': COLORS[idx % COLORS.length] } as any}
                    />
                  </div>
                ))}
                {candidates.length === 0 && <p className="text-xs italic text-muted-foreground text-center">N/A</p>}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
