"use client";

import { useState, useEffect } from 'react';
import { api, Candidate, Voter } from '@/lib/api';
import { useScanner } from '@/hooks/use-scanner';
import { Navigation } from '@/components/Navigation';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Vote as VoteIcon, CheckCircle2, ShieldAlert, Fingerprint, Lock } from 'lucide-react';

export default function VotePage() {
  const lastScan = useScanner();
  const { toast } = useToast();
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [voterStatus, setVoterStatus] = useState<{ status: string, name?: string, uid: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const [voting, setVoting] = useState(false);

  useEffect(() => {
    const loadCandidates = async () => {
      try {
        const candidatesData = await api.getCandidates();
        setCandidates(candidatesData);
      } catch (error) {
        console.error('Failed to load candidates:', error);
      }
    };

    loadCandidates();
    // Poll for updates every 2 seconds
    const interval = setInterval(loadCandidates, 2000);
    return () => clearInterval(interval);
  }, []);

  // Effect to react to hardware scans
  useEffect(() => {
    async function verifyScan() {
      if (!lastScan?.lastScannedUid) return;
      
      const scanAge = Date.now() - lastScan.lastScannedAt;
      if (scanAge > 30000) {
        setVoterStatus(null);
        return;
      }

      setLoading(true);
      try {
        const data = await api.scanRFID(lastScan.lastScannedUid);
        setVoterStatus({ ...data, uid: lastScan.lastScannedUid });
      } catch (error) {
        toast({ title: "Verification Error", variant: "destructive" });
      } finally {
        setLoading(false);
      }
    }
    verifyScan();
  }, [lastScan, toast]);

  const handleCastVote = async (candidateId: string) => {
    if (!voterStatus || voterStatus.status !== 'VALID') return;
    
    setVoting(true);
    try {
      const result = await api.vote(voterStatus.uid, candidateId);
      
      toast({
        title: "Success",
        description: "Your vote has been securely recorded via API.",
      });
      // Force state update to block re-voting in current session
      setVoterStatus({ ...voterStatus, status: 'ALREADY_VOTED' });
    } catch (error: any) {
      toast({
        title: "Voting Failed",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setVoting(false);
    }
  };

  const hasRecentScan = lastScan && (Date.now() - lastScan.lastScannedAt < 30000);

  return (
    <div className="min-h-screen gradient-bg pb-20 md:pt-20">
      <Navigation />
      
      <main className="max-w-5xl mx-auto px-4 pt-12">
        {!hasRecentScan ? (
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
            <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mb-8">
              <Fingerprint className="w-12 h-12 text-primary animate-pulse" />
            </div>
            <h2 className="text-3xl font-headline font-bold mb-4">Ballot Locked</h2>
            <p className="text-muted-foreground max-w-md">The voting system is idle. Scan your registered RFID card on the reader to unlock your ballot.</p>
          </div>
        ) : loading ? (
          <div className="flex flex-col items-center justify-center min-h-[60vh]">
            <Loader2 className="w-12 h-12 text-primary animate-spin mb-4" />
            <p className="text-muted-foreground">Authenticating RFID UID...</p>
          </div>
        ) : voterStatus?.status === 'NOT_REGISTERED' ? (
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
            <div className="w-24 h-24 bg-destructive/10 rounded-full flex items-center justify-center mb-8">
              <ShieldAlert className="w-12 h-12 text-destructive" />
            </div>
            <h2 className="text-3xl font-headline font-bold mb-4">Unauthorized Card</h2>
            <p className="text-muted-foreground mb-6">UID: <span className="font-code font-bold text-foreground">{voterStatus.uid}</span></p>
            <p className="bg-destructive/10 text-destructive px-4 py-2 rounded-full text-sm font-medium">This card is not registered in the voting database.</p>
          </div>
        ) : voterStatus?.status === 'ALREADY_VOTED' ? (
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
            <div className="w-24 h-24 bg-accent/10 rounded-full flex items-center justify-center mb-8">
              <CheckCircle2 className="w-12 h-12 text-accent" />
            </div>
            <h2 className="text-3xl font-headline font-bold mb-2">Access Denied</h2>
            <p className="text-xl text-primary font-medium mb-4">{voterStatus.name}, you have already cast your vote.</p>
            <div className="flex items-center gap-2 text-muted-foreground text-sm">
              <Lock className="w-4 h-4" />
              Ballot instance for {voterStatus.uid} is expired.
            </div>
          </div>
        ) : voterStatus?.status === 'VALID' ? (
          <div>
            <div className="mb-10 text-center">
              <h1 className="text-4xl font-headline font-bold mb-2">Secure Ballot</h1>
              <p className="text-muted-foreground">Identity Verified: <span className="text-primary font-bold">{voterStatus.name}</span></p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {candidates.map((candidate) => (
                <Card key={candidate.id} className="bg-card/50 backdrop-blur border-border hover:border-primary transition-all duration-300 overflow-hidden group">
                  <div className="h-32 bg-primary/10 flex items-center justify-center">
                    <VoteIcon className="w-12 h-12 text-primary/40 group-hover:text-primary transition-colors" />
                  </div>
                  <CardHeader>
                    <CardTitle className="text-xl">{candidate.name}</CardTitle>
                    <CardDescription>{candidate.position}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button 
                      className="w-full" 
                      onClick={() => handleCastVote(candidate.id)}
                      disabled={voting}
                    >
                      {voting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : "Cast Vote"}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        ) : null}
      </main>
    </div>
  );
}
