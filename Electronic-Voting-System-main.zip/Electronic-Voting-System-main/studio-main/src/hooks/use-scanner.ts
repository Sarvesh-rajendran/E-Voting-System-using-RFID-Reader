"use client";

import { useState, useEffect } from 'react';
import { SystemStatus } from '@/lib/api';

export function useScanner() {
  const [lastScan, setLastScan] = useState<SystemStatus | null>(null);

  useEffect(() => {
    // Poll the backend for system status every 2 seconds
    const interval = setInterval(async () => {
      try {
        const response = await fetch('http://localhost:5000/api/system/status');
        if (response.ok) {
          const data = await response.json() as SystemStatus;
          // Only return scans that happened in the last 60 seconds to avoid stale UIDs
          if (Date.now() - data.lastScannedAt < 60000) {
            setLastScan(data);
          } else {
            setLastScan(null);
          }
        }
      } catch (error) {
        console.error('Failed to fetch scanner status:', error);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return lastScan;
}
