'use server';
/**
 * @fileOverview An AI agent for detecting anomalies in voting activity logs.
 *
 * - detectVotingAnomalies - A function that initiates the anomaly detection process.
 * - DetectVotingAnomaliesInput - The input type for the detectVotingAnomalies function.
 * - DetectVotingAnomaliesOutput - The return type for the detectVotingAnomalies function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const VotingActivityLogEntrySchema = z.object({
  uid: z.string().describe('The RFID UID of the voter.'),
  timestamp: z.string().datetime().describe('The timestamp when the vote was cast (ISO 8601 format).'),
  candidateId: z.string().describe('The ID of the candidate who received the vote.'),
  transactionHash: z.string().describe('The blockchain-style hash of the vote for integrity verification.'),
});

const DetectVotingAnomaliesInputSchema = z.object({
  recentVotingActivityLogs: z.array(VotingActivityLogEntrySchema).describe('A list of recent voting activity logs to analyze for anomalies.'),
});
export type DetectVotingAnomaliesInput = z.infer<typeof DetectVotingAnomaliesInputSchema>;

const DetectVotingAnomaliesOutputSchema = z.object({
  hasAnomalies: z.boolean().describe('True if any unusual or suspicious voting patterns were detected.'),
  summary: z.string().describe('A summary of the detected anomalies, including details on patterns, timestamps, and potential implications.'),
  alertLevel: z.enum(['NONE', 'LOW', 'MEDIUM', 'HIGH']).describe('The severity level of the detected anomalies.'),
  detectedPatterns: z.array(z.string()).describe('A list of specific unusual patterns identified (e.g., "Abnormally fast voting", "Repeated UID voting within short interval").'),
});
export type DetectVotingAnomaliesOutput = z.infer<typeof DetectVotingAnomaliesOutputSchema>;

export async function detectVotingAnomalies(input: DetectVotingAnomaliesInput): Promise<DetectVotingAnomaliesOutput> {
  return detectVotingAnomaliesFlow(input);
}

const prompt = ai.definePrompt({
  name: 'votingAnomalyDetectionPrompt',
  input: {schema: DetectVotingAnomaliesInputSchema},
  output: {schema: DetectVotingAnomaliesOutputSchema},
  prompt: `You are an AI-powered election anomaly detection system. Your task is to analyze recent voting activity logs and identify any unusual or suspicious patterns that could indicate security breaches or irregularities in the election process.

Consider the following as potential anomalies:
-   **Abnormally fast voting**: Multiple votes registered within a very short timeframe that is humanly improbable.
-   **Repeated UID voting**: The same RFID UID appearing multiple times in the logs after having already voted (which should be prevented by the system, but check for attempts).
-   **Unexpected voting sequences**: Patterns that deviate from normal voting behavior.
-   **Sudden spikes**: A sudden, unexplainable increase in voting activity for a specific candidate or in general.

Analyze the following voting activity logs:

Recent Voting Activity Logs:
{{{JSON.stringify recentVotingActivityLogs}}}

Based on your analysis, determine if any anomalies are present, provide a summary of what you found, assign an alert level, and list the specific patterns you identified.`,
});

const detectVotingAnomaliesFlow = ai.defineFlow(
  {
    name: 'detectVotingAnomaliesFlow',
    inputSchema: DetectVotingAnomaliesInputSchema,
    outputSchema: DetectVotingAnomaliesOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
