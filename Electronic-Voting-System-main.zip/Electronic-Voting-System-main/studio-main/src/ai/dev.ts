import { config } from 'dotenv';
config();

import '@/ai/flows/voting-anomaly-detector.ts';