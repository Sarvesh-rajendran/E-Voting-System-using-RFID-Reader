const API_BASE_URL = 'http://10.233.6.240:5000';

export interface Voter {
  uid: string;
  name: string;
  department: string;
  registerNumber: string;
  year: string;
  hasVoted: boolean;
  timestamp?: any;
}

export interface Candidate {
  id: string;
  name: string;
  votes: number;
  position: string;
}

export interface VoteLog {
  uid: string;
  candidateId: string;
  timestamp: string;
  transactionHash: string;
}

export interface SystemStatus {
  lastScannedUid: string;
  lastScannedAt: number;
}

export const api = {
  // RFID Scanner API
  scanRFID: async (uid: string) => {
    const response = await fetch(`${API_BASE_URL}/api/rfid/scan`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ uid })
    });
    if (!response.ok) throw new Error('Failed to scan RFID');
    return response.json();
  },

  // Voting API
  vote: async (uid: string, candidateId: string) => {
    const response = await fetch(`${API_BASE_URL}/api/vote`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ uid, candidateId })
    });
    if (!response.ok) throw new Error('Failed to cast vote');
    return response.json();
  },

  // Get statistics
  getStats: async () => {
    const response = await fetch(`${API_BASE_URL}/api/dashboard/stats`);
    if (!response.ok) throw new Error('Failed to get stats');
    return response.json();
  },

  // Add new voter
  
addVoter: async (voterData: Voter) => {
  const response = await fetch(`${API_BASE_URL}/api/admin/add-voter`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(voterData)
  });

  if (!response.ok) {
    const err = await response.text();
    console.error('Add voter error:', err);
    throw new Error('Failed to add voter');
  }

  return response.json();
},
  // Get all voters
  getVoters: async (): Promise<Voter[]> => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/dashboard/voters`);
      if (!response.ok) {
        const errorText = await response.text();
        console.error('Voters API Error:', response.status, errorText);
        throw new Error(`Failed to get voters: ${response.status}`);
      }
      const voters = await response.json();
      console.log('Voters data:', voters);
      // Map backend data to frontend format with fallbacks
      return voters.map((voter: any) => ({
        uid: voter.uid || '',
        name: voter.name || '',
        department: voter.department || 'Unknown',
        registerNumber: voter.registerNumber || '',
        year: voter.year || '',
        hasVoted: voter.hasVoted || false,
        timestamp: voter.timestamp
      }));
    } catch (error) {
      console.error('getVoters error:', error);
      throw error;
    }
  },

  // Get all candidates
  getCandidates: async (): Promise<Candidate[]> => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/dashboard/candidates`);
      if (!response.ok) {
        const errorText = await response.text();
        console.error('Candidates API Error:', response.status, errorText);
        throw new Error(`Failed to get candidates: ${response.status}`);
      }
      const candidates = await response.json();
      console.log('Candidates data:', candidates);
      // Map voteCount to votes for frontend compatibility
      return candidates.map((candidate: any) => ({
        id: candidate._id,
        name: candidate.name || '',
        position: candidate.position || '',
        votes: candidate.voteCount || 0
      }));
    } catch (error) {
      console.error('getCandidates error:', error);
      throw error;
    }
  },

  // Add candidate
  addCandidate: async (candidateData: Omit<Candidate, 'id'>) => {
    const response = await fetch(`${API_BASE_URL}/api/admin/add-candidate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(candidateData)
    });
    if (!response.ok) throw new Error('Failed to add candidate');
    return response.json();
  },

  // Delete candidate
  deleteCandidate: async (candidateId: string) => {
    const response = await fetch(`${API_BASE_URL}/api/admin/candidates/${candidateId}`, {
      method: 'DELETE'
    });
    if (!response.ok) throw new Error('Failed to delete candidate');
    return response.json();
  },

  // Get vote logs
  getVoteLogs: async (): Promise<VoteLog[]> => {
    const response = await fetch(`${API_BASE_URL}/api/dashboard/votes`);
    if (!response.ok) throw new Error('Failed to get vote logs');
    const votes = await response.json();
    // Map backend data to frontend format
    return votes.map((vote: any) => ({
      uid: vote.uid,
      candidateId: vote.candidateId._id || vote.candidateId,
      timestamp: vote.timestamp,
      transactionHash: vote.transactionHash
    }));
  },

  // Get recent scans
  getRecentScans: async () => {
    const response = await fetch(`${API_BASE_URL}/api/dashboard/scans/recent`);
    if (!response.ok) throw new Error('Failed to get recent scans');
    return response.json();
  },

  // Reset votes
  resetVotes: async () => {
    const response = await fetch(`${API_BASE_URL}/api/admin/reset`, {
      method: 'POST'
    });
    if (!response.ok) throw new Error('Failed to reset votes');
    return response.json();
  }
};
