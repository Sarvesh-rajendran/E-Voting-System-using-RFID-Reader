# **App Name**: SecureVote RFID

## Core Features:

- RFID Data Ingestion & API: Securely receive RFID UID from ESP32 hardware via a dedicated POST API endpoint, ensuring UIDs are non-manual and validated at the backend.
- Voter Registration Flow: User interface for new voter registration; scans an RFID card to capture UID, collects associated voter details, stores them securely in Firebase Firestore, and ensures UID uniqueness.
- Secure Voting Process: Interactive module where an RFID scan identifies the voter, displays their name, enables a single vote for a chosen candidate, updates their 'hasVoted' status in Firebase Firestore, and prevents duplicate voting.
- Real-Time Election Dashboard: A dynamic, real-time dashboard displaying total registered voters, total votes cast, and candidate-wise vote counts, updating instantly with Firebase Firestore listeners.
- Admin Panel & Candidate Management: Secure admin access via Firebase Authentication to add, modify, or remove election candidates, with all data managed in Firebase Firestore.
- Election Reset Tool: Admin tool to initiate a full election reset, which clears all recorded votes and resets the 'hasVoted' status for all voters within Firebase Firestore.
- Integrity & Anomaly Monitoring Tool: An AI-powered tool that analyzes voting activity for suspicious patterns or anomalies, incorporating blockchain-style vote hashing for verifiable integrity of each ballot logged in Firebase Firestore.

## Style Guidelines:

- Primary color: A vibrant, yet deep blue (#55A1FF), conveying trustworthiness and digital precision for key interactive elements.
- Background color: A very dark, slightly desaturated blue-grey (#15181C), creating a professional and secure ambiance for the main interface.
- Accent color: A light, almost cyan blue (#B8ECFF), providing high contrast for highlights and important notifications.
- Headline and body font: 'Inter' (sans-serif), chosen for its modern, neutral, and objective appearance, ensuring readability and professionalism for all text.
- Utilize minimalistic, vector-based icons that visually communicate concepts of security, voting, verification, and real-time updates.
- Employ a clean, structured layout with clear divisions between sections, ensuring a responsive design that prioritizes ease of use for voters and efficient data management for administrators.
- Implement subtle transition animations for real-time dashboard updates and clear visual feedback for successful RFID scans and voting confirmations.