# RFID Voting System Backend

Complete Node.js + Express backend for RFID-based voting system.

## Prerequisites

- Node.js (v14 or higher)
- MongoDB (running on localhost:27017)

## Setup

### 1. Install Dependencies
```bash
npm install
```

### 2. Environment Variables
Create `.env` file:
```
MONGO_URI=mongodb://localhost:27017/voting
PORT=5000
NODE_ENV=development
```

### 3. Start MongoDB
Make sure MongoDB is running on localhost:27017

### 4. Run Server
```bash
# Development (with auto-restart)
npm run dev

# Production
npm start
```

## API Endpoints

### RFID Routes
- `POST /api/rfid/scan` - Scan RFID card
- `GET /api/system/status` - System status for scanner

### Vote Routes
- `POST /api/vote` - Cast vote

### Admin Routes
- `POST /api/admin/add-voter` - Add new voter
- `POST /api/admin/add-candidate` - Add new candidate
- `DELETE /api/admin/candidates/:id` - Delete candidate
- `DELETE /api/admin/voters/:uid` - Delete voter
- `POST /api/admin/reset` - Reset entire system

### Dashboard Routes
- `GET /api/dashboard/stats` - Get all statistics
- `GET /api/dashboard/voters` - Get all voters
- `GET /api/dashboard/candidates` - Get all candidates
- `GET /api/dashboard/votes` - Get all votes
- `GET /api/dashboard/scans/recent` - Get recent scans

### Health Check
- `GET /health` - Server health status

## Network Access

Server runs on `0.0.0.0:5000` making it accessible from:
- Local: http://localhost:5000
- Network: http://<your-ip>:5000

## Database Models

### Voter
- uid (String, unique)
- name (String)
- department (String)
- registerNumber (String)
- year (String)
- hasVoted (Boolean, default false)

### Candidate
- name (String)
- position (String)
- voteCount (Number, default 0)

### Vote
- uid (String)
- candidateId (ObjectId)
- timestamp (Date)
- transactionHash (String)

### ScanLog
- uid (String)
- timestamp (Date)
- epoch (Number)

## Features

✅ Complete CRUD operations
✅ RFID scanning with validation
✅ Secure voting with duplicate prevention
✅ Real-time statistics
✅ Admin management
✅ System reset functionality
✅ Error handling
✅ Network accessibility
✅ MongoDB integration
