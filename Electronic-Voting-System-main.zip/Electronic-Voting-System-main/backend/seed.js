const mongoose = require('mongoose');
const Voter = require('./models/Voter');
const Candidate = require('./models/Candidate');
require('dotenv').config();

const seedData = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('Connected to MongoDB');

    // Clear existing data
    await Voter.deleteMany({});
    await Candidate.deleteMany({});

    // Add sample candidates
    const candidates = [
      { name: 'Alice Johnson', position: 'President', voteCount: 0 },
      { name: 'Bob Smith', position: 'President', voteCount: 0 },
      { name: 'Carol Davis', position: 'Vice President', voteCount: 0 },
      { name: 'David Wilson', position: 'Vice President', voteCount: 0 }
    ];

    await Candidate.insertMany(candidates);
    console.log('Sample candidates added');

    // Add sample voters
    const voters = [
      { uid: 'A1B2C3D4', name: 'John Doe', department: 'CSE', registerNumber: 'REG001', year: '3rd', hasVoted: false },
      { uid: 'E5F6G7H8', name: 'Jane Smith', department: 'ECE', registerNumber: 'REG002', year: '2nd', hasVoted: false },
      { uid: 'I9J0K1L2', name: 'Mike Johnson', department: 'MECH', registerNumber: 'REG003', year: '4th', hasVoted: false }
    ];

    await Voter.insertMany(voters);
    console.log('Sample voters added');

    console.log('Database seeded successfully!');
    process.exit(0);
  } catch (error) {
    console.error('Seeding error:', error);
    process.exit(1);
  }
};

seedData();
