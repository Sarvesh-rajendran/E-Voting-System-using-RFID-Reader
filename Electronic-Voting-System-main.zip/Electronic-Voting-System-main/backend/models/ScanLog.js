const mongoose = require('mongoose');

const scanLogSchema = new mongoose.Schema({
  uid: {
    type: String,
    required: true
  },
  timestamp: {
    type: Date,
    default: Date.now
  },
  epoch: {
    type: Number,
    default: () => Date.now()
  }
});

module.exports = mongoose.model('ScanLog', scanLogSchema);
