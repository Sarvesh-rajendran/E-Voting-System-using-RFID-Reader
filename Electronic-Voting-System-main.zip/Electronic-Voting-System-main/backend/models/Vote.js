const mongoose = require('mongoose');

const voteSchema = new mongoose.Schema({
  uid: {
    type: String,
    required: true
  },
  candidateId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Candidate',
    required: true
  },
  timestamp: {
    type: Date,
    default: Date.now
  },
  transactionHash: {
    type: String,
    default: 'SECURE_API_LOG'
  }
});

module.exports = mongoose.model('Vote', voteSchema);
