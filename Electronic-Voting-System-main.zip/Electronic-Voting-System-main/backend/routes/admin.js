const express = require('express');
const router = express.Router();
const Voter = require('../models/Voter');
const Candidate = require('../models/Candidate');
const Vote = require('../models/Vote');
const ScanLog = require('../models/ScanLog');

// POST /api/admin/add-voter
router.post('/add-voter', async (req, res) => {
  try {
    const { name, department, registerNumber, year, uid } = req.body;

    if (!name || !department || !registerNumber || !year || !uid) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    // Check if voter already exists
    const existingVoter = await Voter.findOne({ uid });
    if (existingVoter) {
      return res.status(400).json({ error: 'Voter with this UID already exists' });
    }

    // Create new voter
    const voter = new Voter({
      uid,
      name,
      department,
      registerNumber,
      year,
      hasVoted: false
    });

    await voter.save();
    res.json({ success: true, message: 'Voter added successfully', voter });

  } catch (error) {
    console.error('Add Voter Error:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// POST /api/admin/add-candidate
router.post('/add-candidate', async (req, res) => {
  try {
    const { name, position } = req.body;

    if (!name || !position) {
      return res.status(400).json({ error: 'Name and position are required' });
    }

    // Create new candidate
    const candidate = new Candidate({
      name,
      position,
      voteCount: 0
    });

    await candidate.save();
    res.json({ success: true, message: 'Candidate added successfully', candidate });

  } catch (error) {
    console.error('Add Candidate Error:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// DELETE /api/admin/candidates/:id
router.delete('/candidates/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const candidate = await Candidate.findByIdAndDelete(id);
    if (!candidate) {
      return res.status(404).json({ error: 'Candidate not found' });
    }

    res.json({ success: true, message: 'Candidate deleted successfully' });

  } catch (error) {
    console.error('Delete Candidate Error:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// DELETE /api/admin/voters/:uid
router.delete('/voters/:uid', async (req, res) => {
  try {
    const { uid } = req.params;

    const voter = await Voter.findOneAndDelete({ uid });
    if (!voter) {
      return res.status(404).json({ error: 'Voter not found' });
    }

    res.json({ success: true, message: 'Voter deleted successfully' });

  } catch (error) {
    console.error('Delete Voter Error:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// POST /api/admin/reset
router.post('/reset', async (req, res) => {
  try {
    // Reset all candidates vote counts
    await Candidate.updateMany({}, { voteCount: 0 });

    // Reset all voters hasVoted status
    await Voter.updateMany({}, { hasVoted: false });

    // Delete all votes
    await Vote.deleteMany({});

    // Delete all scan logs
    await ScanLog.deleteMany({});

    res.json({ success: true, message: 'System reset successfully' });

  } catch (error) {
    console.error('Reset Error:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

module.exports = router;
