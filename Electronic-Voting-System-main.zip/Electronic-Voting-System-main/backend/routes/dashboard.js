const express = require('express');
const router = express.Router();
const Voter = require('../models/Voter');
const Candidate = require('../models/Candidate');
const Vote = require('../models/Vote');
const ScanLog = require('../models/ScanLog');

// GET /api/dashboard/stats
router.get('/stats', async (req, res) => {
  try {
    // Get all voters
    const voters = await Voter.find().sort({ timestamp: -1 });

    // Get all candidates
    const candidates = await Candidate.find().sort({ voteCount: -1 });

    // Get all votes
    const votes = await Vote.find().populate('candidateId', 'name').sort({ timestamp: -1 });

    // Get recent scans (last 5)
    const scans = await ScanLog.find().sort({ timestamp: -1 }).limit(5);

    res.json({
      voters,
      candidates,
      votes,
      scans
    });

  } catch (error) {
    console.error('Get Stats Error:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// GET /api/dashboard/voters
router.get('/voters', async (req, res) => {
  try {
    const voters = await Voter.find().sort({ timestamp: -1 });
    res.json(voters);
  } catch (error) {
    console.error('Get Voters Error:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// GET /api/dashboard/candidates
router.get('/candidates', async (req, res) => {
  try {
    const candidates = await Candidate.find().sort({ voteCount: -1 });
    res.json(candidates);
  } catch (error) {
    console.error('Get Candidates Error:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// GET /api/dashboard/votes
router.get('/votes', async (req, res) => {
  try {
    const votes = await Vote.find().populate('candidateId', 'name').sort({ timestamp: -1 });
    res.json(votes);
  } catch (error) {
    console.error('Get Votes Error:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// GET /api/dashboard/scans/recent
router.get('/scans/recent', async (req, res) => {
  try {
    const scans = await ScanLog.find().sort({ timestamp: -1 }).limit(5);
    res.json(scans);
  } catch (error) {
    console.error('Get Recent Scans Error:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

module.exports = router;
