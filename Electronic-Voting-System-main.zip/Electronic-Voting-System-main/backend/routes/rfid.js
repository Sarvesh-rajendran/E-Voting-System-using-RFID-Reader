const express = require('express');
const router = express.Router();
const Voter = require('../models/Voter');
const ScanLog = require('../models/ScanLog');

// 🔥 GLOBAL LAST SCAN (IMPORTANT FOR FRONTEND)
let lastScan = {
  uid: '',
  time: 0
};

// POST /api/rfid/scan
router.post('/scan', async (req, res) => {
  try {
    const { uid } = req.body;

    if (!uid) {
      return res.status(400).json({ error: 'UID is required' });
    }

    // 🔥 UPDATE LAST SCAN (VERY IMPORTANT)
    lastScan.uid = uid;
    lastScan.time = Date.now();

    console.log("📡 RFID Scanned:", uid);

    // Save scan log
    const scanLog = new ScanLog({ uid });
    await scanLog.save();

    // Check if voter exists
    const voter = await Voter.findOne({ uid });

    if (voter) {
      if (voter.hasVoted) {
        return res.json({
          status: 'ALREADY_VOTED',
          name: voter.name,
          hasVoted: true
        });
      }

      return res.json({
        status: 'VALID',
        name: voter.name,
        hasVoted: false
      });
    }

    return res.json({
      status: 'NOT_REGISTERED',
      uid: uid
    });

  } catch (error) {
    console.error('RFID Scan Error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


// 🔥 EXPORT BOTH router + lastScan
module.exports = { router, lastScan };