const express = require('express');
const router = express.Router();
const Voter = require('../models/Voter');
const Candidate = require('../models/Candidate');
const Vote = require('../models/Vote');

// POST /api/vote
router.post('/', async (req, res) => {
  try {
    const { uid, candidateId } = req.body;

    if (!uid || !candidateId) {
      return res.status(400).json({ error: 'UID and CandidateID are required' });
    }

    // Check if voter exists
    const voter = await Voter.findOne({ uid });
    if (!voter) {
      return res.status(404).json({ error: 'Voter not found' });
    }

    // Check if voter has already voted
    if (voter.hasVoted) {
      return res.status(400).json({ error: 'Voter has already cast a ballot' });
    }

    // Check if candidate exists
    const candidate = await Candidate.findById(candidateId);
    if (!candidate) {
      return res.status(404).json({ error: 'Candidate not found' });
    }

    // Save vote
    const vote = new Vote({
      uid,
      candidateId
    });
    await vote.save();

    // Increment candidate vote count
    candidate.voteCount += 1;
    await candidate.save();

    // Update voter status
    voter.hasVoted = true;
    await voter.save();

    res.json({ success: true, message: 'Vote recorded successfully' });

  } catch (error) {
    console.error('Voting Error:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

module.exports = router;
