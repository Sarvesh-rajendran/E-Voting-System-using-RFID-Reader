require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/database');

// 🔥 IMPORT RFID WITH lastScan
const { router: rfidRoutes, lastScan } = require('./routes/rfid');

// Connect to MongoDB
connectDB();

const app = express();

// Middleware
app.use(express.json());
app.use(cors());

// Routes
app.use('/api/rfid', rfidRoutes);
app.use('/api/vote', require('./routes/vote'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/dashboard', require('./routes/dashboard'));

// Health check route
app.get('/health', (req, res) => {
  res.json({ status: "OK", message: "Server running" });
});

// 🔥 FIXED SYSTEM STATUS (VERY IMPORTANT)
app.get('/api/system/status', (req, res) => {
  res.json({
    lastScannedUid: lastScan.uid,
    lastScannedAt: lastScan.time
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Access via: http://localhost:${PORT}`);
  console.log(`Network access: http://0.0.0.0:${PORT}`);
});